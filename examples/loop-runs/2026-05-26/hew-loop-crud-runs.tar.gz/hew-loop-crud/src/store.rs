use crate::todo::Todo;

pub struct TodoStore {
    items: Vec<Todo>,
    next_id: u64,
}

impl TodoStore {
    pub fn new() -> Self {
        Self { items: Vec::new(), next_id: 1 }
    }

    pub fn add(&mut self, title: String) -> u64 {
        let id = self.next_id;
        self.next_id += 1;
        self.items.push(Todo::new(id, title));
        id
    }

    pub fn get(&self, id: u64) -> Option<&Todo> {
        self.items.iter().find(|t| t.id == id)
    }

    pub fn list(&self) -> &[Todo] {
        &self.items
    }

    pub fn mark_done(&mut self, id: u64) -> bool {
        match self.items.iter_mut().find(|t| t.id == id) {
            Some(t) => {
                t.done = true;
                true
            }
            None => false,
        }
    }

    pub fn remove(&mut self, id: u64) -> bool {
        match self.items.iter().position(|t| t.id == id) {
            Some(idx) => {
                self.items.remove(idx);
                true
            }
            None => false,
        }
    }
}

impl Default for TodoStore {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn new_is_empty() {
        let s = TodoStore::new();
        assert!(s.list().is_empty());
    }

    #[test]
    fn add_assigns_incrementing_ids_starting_at_one() {
        let mut s = TodoStore::new();
        assert_eq!(s.add("a".into()), 1);
        assert_eq!(s.add("b".into()), 2);
        assert_eq!(s.add("c".into()), 3);
        assert_eq!(s.list().len(), 3);
    }

    #[test]
    fn get_returns_item_when_present() {
        let mut s = TodoStore::new();
        let id = s.add("buy milk".into());
        let t = s.get(id).expect("just inserted");
        assert_eq!(t.id, id);
        assert_eq!(t.title, "buy milk");
        assert!(!t.done);
    }

    #[test]
    fn get_returns_none_for_missing_id() {
        let s = TodoStore::new();
        assert!(s.get(999).is_none());
    }

    #[test]
    fn mark_done_flips_flag_and_returns_true() {
        let mut s = TodoStore::new();
        let id = s.add("x".into());
        assert!(s.mark_done(id));
        assert!(s.get(id).unwrap().done);
    }

    #[test]
    fn mark_done_returns_false_for_missing_id() {
        let mut s = TodoStore::new();
        assert!(!s.mark_done(42));
    }

    #[test]
    fn remove_drops_item_and_returns_true() {
        let mut s = TodoStore::new();
        let id = s.add("x".into());
        assert!(s.remove(id));
        assert!(s.get(id).is_none());
        assert!(s.list().is_empty());
    }

    #[test]
    fn remove_returns_false_for_missing_id() {
        let mut s = TodoStore::new();
        assert!(!s.remove(7));
    }

    #[test]
    fn ids_are_not_reused_after_remove() {
        let mut s = TodoStore::new();
        let a = s.add("a".into());
        s.remove(a);
        let b = s.add("b".into());
        assert_eq!(b, 2);
    }
}
