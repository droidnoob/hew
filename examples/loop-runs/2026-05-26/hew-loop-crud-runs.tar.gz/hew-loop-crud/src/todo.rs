pub struct Todo {
    pub id: u64,
    pub title: String,
    pub done: bool,
}

impl Todo {
    pub fn new(id: u64, title: String) -> Self {
        Self { id, title, done: false }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn new_sets_done_false() {
        let t = Todo::new(1, "buy milk".to_string());
        assert!(!t.done);
    }

    #[test]
    fn new_copies_title_verbatim() {
        let title = "  Eat   Pie  ".to_string();
        let t = Todo::new(42, title.clone());
        assert_eq!(t.title, title);
        assert_eq!(t.id, 42);
    }
}
