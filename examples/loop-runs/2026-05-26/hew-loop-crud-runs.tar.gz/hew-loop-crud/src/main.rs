use std::env;
use std::process::ExitCode;

use todo::TodoStore;

fn main() -> ExitCode {
    let args: Vec<String> = env::args().skip(1).collect();
    match run(&args) {
        Ok(()) => ExitCode::SUCCESS,
        Err(msg) => {
            eprintln!("{msg}");
            ExitCode::from(1)
        }
    }
}

fn run(args: &[String]) -> Result<(), String> {
    let cmd = args.first().ok_or_else(usage)?;
    let mut store = TodoStore::new();
    match cmd.as_str() {
        "add" => {
            let title = args.get(1).ok_or_else(|| "usage: todo add <title>".to_string())?;
            let id = store.add(title.clone());
            println!("{id}");
            Ok(())
        }
        "list" => {
            for t in store.list() {
                let tag = if t.done { "done" } else { "todo" };
                println!("[{tag}] {}: {}", t.id, t.title);
            }
            Ok(())
        }
        "done" => {
            let id = parse_id(args.get(1), "done")?;
            if store.mark_done(id) {
                println!("marked {id}");
                Ok(())
            } else {
                Err(format!("no todo with id {id}"))
            }
        }
        "rm" => {
            let id = parse_id(args.get(1), "rm")?;
            if store.remove(id) {
                println!("removed {id}");
                Ok(())
            } else {
                Err(format!("no todo with id {id}"))
            }
        }
        other => Err(format!("unknown command: {other}\n{}", usage())),
    }
}

fn parse_id(raw: Option<&String>, cmd: &str) -> Result<u64, String> {
    let s = raw.ok_or_else(|| format!("usage: todo {cmd} <id>"))?;
    s.parse::<u64>().map_err(|_| format!("invalid id: {s}"))
}

fn usage() -> String {
    "usage: todo <add <title>|list|done <id>|rm <id>>".to_string()
}
